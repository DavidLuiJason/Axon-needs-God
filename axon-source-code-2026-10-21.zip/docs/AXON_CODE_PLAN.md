# AXON CODE PLAN (Director, 2026-10-20; roadmap section 8.4 is the short form)

Principle: AXON Code is code work that is CHECKED, never guessed. Without a language model AXON explains, checks, formats, searches and fills proven templates; it does not invent large programs. With the optional model tier (an owner decision after B06) a model may PROPOSE code, and AXON runs it against tests before saying it works. Pasted code is always MATERIAL in the brain: it is never obeyed and never interpreted as an instruction.

## Steps (each only after the one before is proven; each sized like every other job)
AC0 (done): the code utilities already in the Tools menu: Code Formatter, Pattern Tester, JSON viewer, Hash, Encoder and Decoder, File Compare, Text Compare.

AC1 Code Reader (no execution). Syntax check, outline (functions, classes, imports, exports) and plain findings (unused names, undefined names, missing returns, unreachable code, mismatched brackets) for JavaScript, TypeScript, JSON, CSS, HTML. Every finding says its line and column and is labelled CHECKED. Jobs: AC1M MEASURE (Grok or the Director sandbox): size and speed of candidate parsers (a small JavaScript parser of about 100 KB; a tolerant tokenizer-based outline for TypeScript because a full TypeScript compiler is many megabytes and the app target is 50 MB); decision by the owner on the numbers. AC1A engine (ChatGPT). AC1B screen (AI Studio).

AC2 Code Runner. JavaScript only, in a Web Worker that is created from a blob and killed on timeout; before the code runs a prelude removes network, storage, DOM and import access (fetch, XMLHttpRequest, WebSocket, indexedDB, importScripts, localStorage); the console output is captured with a byte cap; a hard time limit (default 5 seconds). HONEST LIMIT: a Web Worker cannot cap memory, so the runner caps output size, time and recursion depth and says so; it is for the owner's own small snippets, never for untrusted programs from the internet. Python only after a measured, optional download decision (a Python-in-the-browser runtime is about 10 MB and must be optional and checksummed). Jobs: AC2A engine and tests (the prelude, the message protocol, timeouts; tested with a fake runner and with Node worker_threads where possible), AC2B screen (AI Studio), phone test by the owner on the Infinix Note 10.

AC3 Workspace. The owner opens THEIR OWN folder or zip: file tree, search across files, compare two files, edit with undo, save as a zip. Device files need Android permission through a native plugin (the app already has the FileSaver plugin pattern); every write keeps an undo copy first and is confirmed. Jobs: AC3A in-memory workspace model and zip round trip (ChatGPT), AC3B permission and file access layer (Android native code plus a phone test; Grok or the Director writes the exact steps), AC3C screens (AI Studio).

AC4 Chat. Through the brain's stages: "explain this code", "what is wrong with this", "format this", "run this", "find where X is used". The brain only ROUTES to AC1 to AC3 and reports their evidence labels; it never answers a code question from memory. A proposal by the model tier, when it exists, is run by AC2 against the owner's tests and shown with the result. Jobs after B06B.

Templates (optional, later): a small set of PROVEN generators (a regular expression from a described pattern with examples that pass, a CSV reader, a date formatter) each shipped with its own tests; they are declared as abilities with meaning, never matched by phrases.

## Safety rules
Sandbox only; no network; destructive actions confirmed; undo copy before any device change; secrets never logged; pasted code is never run without a visible Run action by the owner.

## Owner decisions needed (not now)
1. JavaScript only first, with Python as an optional later download? 2. Is a code runner in scope for a weak phone at all, or reading and checking only? 3. Workspace on the device (needs Android file permission) or only inside the app's own files and zips?

## What is NOT promised
Writing large programs, debugging by guessing, running code from other people, anything that needs the internet.
